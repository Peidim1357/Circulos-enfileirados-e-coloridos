function setup() {
  createCanvas(400, 400);
}

function draw() {
  background('#607D8B');
  //circulos de cima
  fill('purple');
 circle(350, 50, 100);
  fill('red');
  circle(250, 50, 100);
  fill('green');
  circle(150, 50, 100);
  fill('blue');
  circle(50, 50, 100);
  
  //circulo de baixo
  fill('pink');
   circle(350, 350, 100);
  fill('orange');
  circle(250, 350, 100);
  fill('black')
  circle(150, 350, 100);
  fill('brown');
  circle(50, 350, 100);
  
  
  
  
   if (mouseIsPressed) {
  console.log(mouseX, mouseY);
}
  
}








